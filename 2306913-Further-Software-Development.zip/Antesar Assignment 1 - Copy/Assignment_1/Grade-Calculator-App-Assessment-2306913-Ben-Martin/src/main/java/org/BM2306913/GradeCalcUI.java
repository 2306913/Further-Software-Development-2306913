package org.BM2306913;

import javax.swing.*;

public class GradeCalcUI {
    private JPanel panel1;
    private JPanel loginPanel;
}
