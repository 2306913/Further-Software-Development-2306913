import static org.junit.jupiter.api;

public class ValidatePasswordTest {
}
