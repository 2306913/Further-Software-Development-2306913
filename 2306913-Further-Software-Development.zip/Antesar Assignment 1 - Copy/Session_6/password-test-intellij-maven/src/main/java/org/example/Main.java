package org.example;

public class Main {
    public static void main(String[] args) {

        ValidatePasswordTest passTest = new ValidatePasswordTest();

        System.out.println("Hello world!");
    }
}